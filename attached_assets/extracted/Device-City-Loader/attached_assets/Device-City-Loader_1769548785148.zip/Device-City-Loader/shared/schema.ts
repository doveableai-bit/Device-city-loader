import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// We define a schema to help structure the frontend types, 
// even though we will primarily use local state as requested.

export const screens = pgTable("screens", {
  id: serial("id").primaryKey(),
  deviceType: text("device_type").notNull(), // 'desktop', 'laptop', 'tablet', 'mobile'
  city: text("city").notNull(),
  state: text("state").notNull(),
  width: integer("width").notNull(),
  height: integer("height").notNull(),
  userAgent: text("user_agent").notNull(),
  url: text("url"),
  isMuted: boolean("is_muted").default(true),
});

export const insertScreenSchema = createInsertSchema(screens).omit({ id: true });

export type Screen = typeof screens.$inferSelect;
export type InsertScreen = z.infer<typeof insertScreenSchema>;

export const DEVICE_TYPES = [
  { type: 'Mobile', width: 375, height: 667, label: 'iPhone SE' },
  { type: 'Mobile', width: 390, height: 844, label: 'iPhone 12' },
  { type: 'Tablet', width: 768, height: 1024, label: 'iPad Mini' },
  { type: 'Tablet', width: 820, height: 1180, label: 'iPad Air' },
  { type: 'Laptop', width: 1280, height: 800, label: 'MacBook Air' },
  { type: 'Desktop', width: 1920, height: 1080, label: 'Desktop 1080p' },
] as const;

export const US_CITIES = [
  { city: "New York", state: "NY" },
  { city: "Los Angeles", state: "CA" },
  { city: "Chicago", state: "IL" },
  { city: "Houston", state: "TX" },
  { city: "Phoenix", state: "AZ" },
  { city: "Philadelphia", state: "PA" },
  { city: "San Antonio", state: "TX" },
  { city: "San Diego", state: "CA" },
  { city: "Dallas", state: "TX" },
  { city: "San Jose", state: "CA" },
  { city: "Austin", state: "TX" },
  { city: "Jacksonville", state: "FL" },
  { city: "Fort Worth", state: "TX" },
  { city: "Columbus", state: "OH" },
  { city: "Charlotte", state: "NC" },
  { city: "San Francisco", state: "CA" },
  { city: "Indianapolis", state: "IN" },
  { city: "Seattle", state: "WA" },
  { city: "Denver", state: "CO" },
  { city: "Washington", state: "DC" },
  { city: "Boston", state: "MA" },
  { city: "Miami", state: "FL" },
  { city: "Nashville", state: "TN" },
  { city: "Atlanta", state: "GA" },
  { city: "Detroit", state: "MI" },
] as const;
