import { useState, useRef, useEffect } from "react";
import type { ExtendedScreen } from "@/hooks/use-simulator";
import { 
  Smartphone, 
  Tablet, 
  Laptop, 
  Monitor, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Maximize,
  MapPin,
  ExternalLink
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface DeviceScreenProps {
  screen: ExtendedScreen;
  onRefresh: (id: number) => void;
  onToggleMute: (id: number) => void;
}

export function DeviceScreen({ screen, onRefresh, onToggleMute }: DeviceScreenProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const iframeContainerRef = useRef<HTMLDivElement>(null);
  const htmlContainerRef = useRef<HTMLDivElement>(null);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      iframeContainerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", handleChange);
    return () => document.removeEventListener("fullscreenchange", handleChange);
  }, []);

  useEffect(() => {
    if (screen.htmlContent && htmlContainerRef.current) {
      htmlContainerRef.current.innerHTML = "";
      
      const tempDiv = document.createElement("div");
      tempDiv.innerHTML = screen.htmlContent;
      
      const scripts = tempDiv.querySelectorAll("script");
      
      Array.from(tempDiv.childNodes).forEach(node => {
        if (node.nodeName !== "SCRIPT") {
          htmlContainerRef.current?.appendChild(node.cloneNode(true));
        }
      });
      
      scripts.forEach(oldScript => {
        const newScript = document.createElement("script");
        Array.from(oldScript.attributes).forEach(attr => {
          newScript.setAttribute(attr.name, attr.value);
        });
        newScript.textContent = oldScript.textContent;
        htmlContainerRef.current?.appendChild(newScript);
      });
    }
  }, [screen.htmlContent, screen._key]);

  const DeviceIcon = {
    'Mobile': Smartphone,
    'Tablet': Tablet,
    'Laptop': Laptop,
    'Desktop': Monitor
  }[screen.deviceType] || Monitor;

  const hasContent = screen.url || screen.htmlContent;

  return (
    <Card className={cn(
      "group relative overflow-hidden flex flex-col transition-all duration-300 border-border/50 hover:border-primary/50 hover:shadow-2xl animate-screen-enter bg-card",
      isFullscreen ? "fixed inset-0 z-50 rounded-none border-none" : "h-[400px]"
    )} data-testid={`card-screen-${screen.id}`}>
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-3 bg-gradient-to-b from-black/80 to-transparent backdrop-blur-sm transition-transform duration-300 group-hover:translate-y-0 -translate-y-full">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-black/40 border-white/10 text-white backdrop-blur-md">
            <MapPin className="w-3 h-3 mr-1 text-accent" />
            {screen.city}, {screen.state}
          </Badge>
          <div className="hidden sm:flex items-center text-xs text-muted-foreground font-mono bg-black/40 px-2 py-0.5 rounded backdrop-blur-md">
             {screen.width}x{screen.height}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Badge className="bg-primary/20 hover:bg-primary/30 text-primary-foreground border-primary/20 backdrop-blur-md">
            <DeviceIcon className="w-3 h-3 mr-1.5" />
            {screen.deviceType}
          </Badge>
        </div>
      </div>

      <div 
        ref={iframeContainerRef}
        className="flex-1 relative bg-black w-full h-full flex items-center justify-center overflow-hidden"
      >
        {screen.url ? (
          <iframe
            key={screen._key}
            src={screen.url}
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin allow-forms allow-presentation allow-popups"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            referrerPolicy="no-referrer"
          />
        ) : screen.htmlContent ? (
          <div 
            ref={htmlContainerRef}
            key={screen._key}
            className="w-full h-full flex items-center justify-center"
          />
        ) : (
          <div className="flex flex-col items-center justify-center text-muted-foreground/30 p-8 text-center">
            <DeviceIcon className="w-16 h-16 mb-4 opacity-20" />
            <p className="text-sm font-medium uppercase tracking-widest">
              Awaiting Signal
            </p>
            <div className="mt-2 text-xs font-mono opacity-50">
              {screen.userAgent.substring(0, 40)}...
            </div>
          </div>
        )}

        <div className="absolute inset-0 pointer-events-none bg-gradient-to-tr from-white/5 to-transparent opacity-20" />
        <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_100px_rgba(0,0,0,0.5)]" />
      </div>

      <div className="absolute bottom-0 left-0 right-0 z-20 p-3 bg-gradient-to-t from-black/90 via-black/60 to-transparent flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <div className="flex gap-2">
          <Button 
            size="icon" 
            variant="ghost" 
            className="h-8 w-8 text-white/70 hover:text-white hover:bg-white/10 rounded-full"
            onClick={() => onRefresh(screen.id)}
            title="Reload Screen"
            data-testid={`button-reload-${screen.id}`}
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
          
          <Button 
            size="icon" 
            variant="ghost" 
            className="h-8 w-8 text-white/70 hover:text-white hover:bg-white/10 rounded-full"
            onClick={() => onToggleMute(screen.id)}
            title={screen.isMuted ? "Unmute" : "Mute"}
            data-testid={`button-mute-${screen.id}`}
          >
            {screen.isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </Button>
        </div>

        <div className="flex gap-2">
           {screen.url && (
             <Button
                size="icon"
                variant="ghost"
                className="h-8 w-8 text-white/70 hover:text-white hover:bg-white/10 rounded-full"
                asChild
             >
               <a href={screen.url} target="_blank" rel="noopener noreferrer" title="Open in New Tab" data-testid={`link-external-${screen.id}`}>
                 <ExternalLink className="w-4 h-4" />
               </a>
             </Button>
           )}
           <Button 
            size="icon" 
            variant="ghost" 
            className="h-8 w-8 text-white/70 hover:text-white hover:bg-white/10 rounded-full"
            onClick={toggleFullscreen}
            title="Fullscreen"
            data-testid={`button-fullscreen-${screen.id}`}
          >
            <Maximize className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}
