import { useState, useCallback, useEffect } from "react";
import { DEVICE_TYPES, US_CITIES, type Screen } from "@shared/schema";

export type EmbedMode = "url" | "html";

// Extended screen type with HTML embed support
export interface ExtendedScreen extends Screen {
  _key?: number;
  htmlContent?: string | null;
}

// Helper to generate a random screen configuration
function generateRandomScreen(id: number): ExtendedScreen {
  const device = DEVICE_TYPES[Math.floor(Math.random() * DEVICE_TYPES.length)];
  const location = US_CITIES[Math.floor(Math.random() * US_CITIES.length)];
  
  // Simulated User Agent generation
  let ua = "";
  if (device.type === 'Mobile' || device.type === 'Tablet') {
    ua = `Mozilla/5.0 (${device.label}; CPU OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1`;
  } else {
    ua = `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36`;
  }

  return {
    id,
    deviceType: device.type,
    city: location.city,
    state: location.state,
    width: device.width,
    height: device.height,
    userAgent: ua,
    url: null,
    isMuted: true,
    htmlContent: null,
  };
}

export function useSimulator() {
  const [screens, setScreens] = useState<ExtendedScreen[]>([]);
  const [screenCount, setScreenCount] = useState(4);
  const [globalUrl, setGlobalUrl] = useState("");
  const [embedMode, setEmbedMode] = useState<EmbedMode>("url");
  const [htmlCode, setHtmlCode] = useState("");

  // Initialize screens
  useEffect(() => {
    resetScreens();
  }, [screenCount]);

  const resetScreens = useCallback(() => {
    const newScreens = Array.from({ length: screenCount }).map((_, i) => 
      generateRandomScreen(i + 1)
    );
    // If there was a global URL set previously, keep it on reset? 
    // Usually reset implies new devices, but user might want to keep the URL.
    // Let's clear the individual screen URLs but keep the input state ready to apply.
    if (globalUrl) {
      newScreens.forEach(s => s.url = globalUrl);
    }
    setScreens(newScreens);
  }, [screenCount, globalUrl]);

  const loadUrlOnAll = useCallback(() => {
    if (embedMode === "url") {
      if (!globalUrl) return;
      setScreens(prev => prev.map(s => ({ ...s, url: globalUrl, htmlContent: null })));
    } else {
      if (!htmlCode) return;
      setScreens(prev => prev.map(s => ({ ...s, url: null, htmlContent: htmlCode })));
    }
  }, [globalUrl, htmlCode, embedMode]);

  const updateScreenUrl = useCallback((id: number, url: string) => {
    setScreens(prev => prev.map(s => s.id === id ? { ...s, url } : s));
  }, []);

  const toggleMute = useCallback((id: number) => {
    setScreens(prev => prev.map(s => s.id === id ? { ...s, isMuted: !s.isMuted } : s));
  }, []);

  const refreshScreen = useCallback((id: number) => {
    // Force iframe reload by momentarily clearing URL or adding a timestamp param
    // Simple way: re-assign same URL to trigger React diff if key changes, 
    // but better is to handle the key in the component. 
    // Here we will just update a "timestamp" query param or let the component handle the key.
    // Let's just assume the component handles the reload logic via a key prop change.
    setScreens(prev => prev.map(s => {
      if (s.id !== id) return s;
      // We can't easily force a reload without changing state. 
      // Let's toggle a dummy state or assume the View component handles it.
      // Actually, standard way is to update the key.
      return { ...s, _key: Date.now() }; // We'll add a transient property for key
    }));
  }, []);

  return {
    screens,
    screenCount,
    setScreenCount,
    globalUrl,
    setGlobalUrl,
    loadUrlOnAll,
    resetScreens,
    updateScreenUrl,
    toggleMute,
    refreshScreen,
    embedMode,
    setEmbedMode,
    htmlCode,
    setHtmlCode
  };
}
